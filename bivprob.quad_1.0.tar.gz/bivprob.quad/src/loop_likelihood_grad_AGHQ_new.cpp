//#include <Rcpp.h>
#include <RcppArmadillo.h>
#include <cstdlib>
#include <vector>
#include <iostream>
#include <iomanip>
#include <ctime>
#include <cmath>
#include <numeric>

// [[Rcpp::depends(RcppArmadillo)]]
using namespace Rcpp;
using namespace arma;
using namespace std;

// This is a simple example of exporting a C++ function to R. You can
// source this function into an R session using the Rcpp::sourceCpp 
// function (or via the Source button on the editor toolbar). Learn
// more about Rcpp at:
//
//   http://www.rcpp.org/
//   http://adv-r.had.co.nz/Rcpp.html
//   http://gallery.rcpp.org/
//

# include "toms462.hpp"

// Function for bivariate normal cdf
inline double bivnor ( double ah, double ak, double r )
{
  double a2;
  double ap;
  double b;
  double cn;
  double con;
  double conex;
  double ex;
  double g2;
  double gh;
  double gk;
  double gw;
  double h2;
  double h4;
  int i;
  static int idig = 15;
  int is;
  double rr;
  double s1;
  double s2;
  double sgn;
  double sn;
  double sp;
  double sqr;
  double t;
  static double twopi = 6.283185307179587;
  double w2;
  double wh;
  double wk;
  
  b = 0.0;
  
  ah = -ah;
  ak = -ak;
  
  gh = gauss ( - ah ) / 2.0;
  gk = gauss ( - ak ) / 2.0;
  
  if ( r == 0.0 )
  {
    b = 4.00 * gh * gk;
    b = r8_max ( b, 0.0 );
    b = r8_min ( b, 1.0 );
    return b;
  }
  
  rr = ( 1.0 + r ) * ( 1.0 - r );
  
  if ( rr < 0.0 )
  {
    cerr << "\n";
    cerr << "BIVNOR - Fatal error!\n";
    cerr << "  1 < |R|.\n";
    exit ( 0 );
  }
  
  if ( rr == 0.0 )
  {
    if ( r < 0.0 )
    {
      if ( ah + ak < 0.0 )
      {
        b = 2.0 * ( gh + gk ) - 1.0;
      }
    }
    else
    {
      if ( ah - ak < 0.0 )
      {
        b = 2.0 * gk;
      }
      else
      {
        b = 2.0 * gh;
      }
    }
    b = r8_max ( b, 0.0 );
    b = r8_min ( b, 1.0 );
    return b;
  }
  
  sqr = sqrt ( rr );
  
  if ( idig == 15 )
  {
    con = twopi * 1.0E-15 / 2.0;
  }
  else
  {
    con = twopi / 2.0;
    for ( i = 1; i <= idig; i++ )
    {
      con = con / 10.0;
    }
  }
  //
  //  (0,0)
  //
  if ( ah == 0.0 && ak == 0.0 )
  {
    b = 0.25 + asin ( r ) / twopi;
    b = r8_max ( b, 0.0 );
    b = r8_min ( b, 1.0 );
    return b;
  }
  //
  //  (0,nonzero)
  //
  if ( ah == 0.0 && ak != 0.0 )
  {
    b = gk;
    wh = -ak;
    wk = ( ah / ak - r ) / sqr;
    gw = 2.0 * gk;
    is = 1;
  }
  //
  //  (nonzero,0)
  //
  else if ( ah != 0.0 && ak == 0.0 )
  {
    b = gh;
    wh = -ah;
    wk = ( ak / ah - r ) / sqr;
    gw = 2.0 * gh;
    is = -1;
  }
  //
  //  (nonzero,nonzero)
  //
  else if ( ah != 0.0 && ak != 0.0 )
  {
    b = gh + gk;
    if ( ah * ak < 0.0 )
    {
      b = b - 0.5;
    }
    wh = - ah;
    wk = ( ak / ah - r ) / sqr;
    gw = 2.0 * gh;
    is = -1;
  }
  
  for ( ; ; )
  {
    sgn = -1.0;
    t = 0.0;
    
    if ( wk != 0.0 )
    {
      if ( r8_abs ( wk ) == 1.0 )
      {
        t = wk * gw * ( 1.0 - gw ) / 2.0;
        b = b + sgn * t;
      }
      else
      {
        if ( 1.0 < r8_abs ( wk ) )
        {
          sgn = -sgn;
          wh = wh * wk;
          g2 = gauss ( wh );
          wk = 1.0 / wk;
          
          if ( wk < 0.0 )
          {
            b = b + 0.5;
          }
          b = b - ( gw + g2 ) / 2.0 + gw * g2;
        }
        h2 = wh * wh;
        a2 = wk * wk;
        h4 = h2 / 2.0;
        ex = exp ( - h4 );
        w2 = h4 * ex;
        ap = 1.0;
        s2 = ap - ex;
        sp = ap;
        s1 = 0.0;
        sn = s1;
        conex = r8_abs ( con / wk );
        
        for ( ; ; )
        {
          cn = ap * s2 / ( sn + sp );
          s1 = s1 + cn;
          
          if ( r8_abs ( cn ) <= conex )
          {
            break;
          }
          sn = sp;
          sp = sp + 1.0;
          s2 = s2 - w2;
          w2 = w2 * h4 / sp;
          ap = - ap * a2;
        }
        t = ( atan ( wk ) - wk * s1 ) / twopi;
        b = b + sgn * t;
      }
    }
    if ( 0 <= is )
    {
      break;
    }
    if ( ak == 0.0 )
    {
      break;
    }
    wh = -ak;
    wk = ( ah / ak - r ) / sqr;
    gw = 2.0 * gk;
    is = 1;
  }
  
  b = r8_max ( b, 0.0 );
  b = r8_min ( b, 1.0 );
  
  return b;
}


double gauss ( double t )
{
  double value;
  
  value = ( 1.0 + erf ( t / sqrt ( 2.0 ) ) ) / 2.0;
  
  return value;
}


inline double r8_abs ( double x )
  
{
  double value;
  
  if ( 0.0 <= x )
  {
    value = + x;
  }
  else
  {
    value = - x;
  }
  return value;
}


inline double r8_max ( double x, double y )
{
  double value;
  
  if ( y < x )
  {
    value = x;
  }
  else
  {
    value = y;
  }
  return value;
}

inline double r8_min ( double x, double y )
{
  double value;
  
  if ( y < x )
  {
    value = y;
  }
  else
  {
    value = x;
  }
  return value;
}

// Function for normal cdf
inline double N(double z) {
  if(z > 6.0) {return 1.0;};
  if(z < -6.0) {return 0.0;};
  
  double b1 = 0.31938153;
  double b2 = -0.356563782;
  double b3 = 1.781477937;
  double b4 = -1.821255978;
  double b5 = 1.330274429;
  double p = 0.2316419;
  double c2 = 0.3989423;
  
  double a = fabs(z);
  double t = 1.0/(1.0+a*p);
  double b = c2*exp((-z)*(z/2.0));
  double n = ((((b5*t+b4)*t+b3)*t+b2)*t+b1)*t;
  n = 1.0-b*n;
  if(z < 0.0) n = 1.0 - n;
  return n;
};

// Function for normal pdf
inline double dn(double z) {
  return (1.0/sqrt(2.0*PI))*exp(-0.5*z*z);
};

// Function for bivariate normal pdf
inline double biv_pdf(double x, double y, double rho) {
  double u = x / 1 ;
  double v = y / 1 ;
  double c = 1 - rho*rho ;
  double p = (1 / (2 * M_PI * 1 * 1 * sqrt(c))) 
    * exp (-(u * u - 2 * rho * u * v + v * v) / (2 * c));
  return p;
};

// Function for group product
NumericVector groupProd(NumericVector v, NumericVector group){
  vec V = as<vec>(v);
  ivec G = as<ivec>(group);
  uword nGroup = G.n_elem - 1;
  vec z = zeros<vec> (nGroup);
  for(uword i=0; i< nGroup; i++) z[i] = prod(V.subvec(G[i], G[i+1]-1));
  return wrap(z);
};

// Function for group sum
NumericVector groupSum(NumericVector v, NumericVector group){
  vec V = as<vec>(v);
  ivec G = as<ivec>(group);
  uword nGroup = G.n_elem - 1;
  vec z = zeros<vec> (nGroup);
  for(uword i=0; i< nGroup; i++) z[i] = sum(V.subvec(G[i], G[i+1]-1));
  return wrap(z);
};



// From NumericMatrix to arma::mat
arma::mat trans(NumericMatrix x) {
  arma::mat y = as<arma::mat>(x) ;
  return(y) ;
};

// From NumericVector to arma::vec
arma::vec trans2(NumericVector x) {
  arma::vec y = as<arma::vec>(x) ;
  return(y) ;
};


// From arma::vec to NumericVector
NumericVector trans_back(arma::vec x) {
  NumericVector y = wrap(x) ;
  return(y) ;
};


// Function for Matrix multiplication with vector
NumericVector matmult(NumericMatrix x, NumericVector y) {
  arma::mat x1 = trans(x);
  arma::vec y1 = trans2(y);
  arma::vec mult = x1*y1;
  NumericVector res=trans_back(mult);
  return(res);
};

// Function which multiplies scalar with vector and the resulting matrix with a vector
NumericVector matmult_total(NumericMatrix x, NumericVector y, double z) {
  NumericMatrix res1 = x*z;
  NumericVector res2 = matmult(res1,y);
  return(res2);
};



// Equivalent function for "which()"
IntegerVector c_which(IntegerVector group, int elem){
  int n=group.size();
  
  std::vector<int> ind(n, 0); // Create a n element vector containing all 0's
  
  for(int i=0; i < n; ++i) { 
    ind[i] = group[i];
  };
  
  //std::vector<int> ind=group;
  std::vector<int> out(ind);
  std::vector<int>::iterator it;
  int j = 0;
  it = std::find(ind.begin(), ind.end(), elem);
  while(it++ != ind.end()){
    out[j++] = it - ind.begin();
    it = std::find(it, ind.end(), elem);
  }
  out.resize(j);
  
  int r=out.size();
  IntegerVector out2(r);
  
  for(int i=0; i < r; ++i) { 
    out2[i] = out[i];
  };
  
  return out2;
};


// [[Rcpp::export]]
double mode(NumericVector par, int x, IntegerVector yS, IntegerVector yO, NumericVector linpredS, NumericVector linpredO, NumericVector group_aux, double rho, double tau, double sigma1, double sigma2) {
  
  double alpha1 = par[0];
  double alpha2 = par[1];
  
  int n = yS.size();
  
  NumericVector sum(n);
  
  if((round(tau*100)/100)==1){
    tau = 0.9999;
  };
  
  if((round(tau*100)/100)==-1){
    tau = -0.9999;
  };
  
  if((round(rho*100)/100)==1){
    rho = 0.9999;
  };
  
  if((round(rho*100)/100)==-1){
    rho = -0.9999;
  };
  
  if(sigma1 > 700){
    sigma1 = exp(300);
  };
  
  if(sigma2 > 700){
    sigma2 = exp(300);
  };
  
  if(sigma1 < -700){
    sigma1 = exp(-300);
  };
  
  if(sigma2 < -700){
    sigma2 = exp(-300);
  };
  
  
  if(sigma1 == 0){
    sigma1 =  1.1111e-300 ;
  };
  
  if(sigma2 == 0){
    sigma2 =  1.1111e-300 ;
  };
  
  for(int i=0; i < n; ++i) {  
    if (yS[i]==0) {
      sum[i] = N(-(linpredS[i]+alpha1));
    }
    else if (yS[i]==1 && yO[i]==1) {
      sum[i] = bivnor(linpredS[i]+alpha1,linpredO[i]+alpha2,rho);
    }
    else if (yS[i]==1 && yO[i]==0) {
      sum[i] = bivnor(linpredS[i]+alpha1,-(linpredO[i]+alpha2),-rho);
    };
    if (sum[i]==0) {
      sum[i] = 1.1111e-300;
    };
  };
  
  NumericVector prod = groupSum(log(sum), group_aux);
  
  double prod2 = prod[x-1];
  double sd1 = sqrt(sigma1);
  double sd2 = sqrt(sigma2);
  double temp5 = 1 - pow(tau,2);
  
  double zedd1 = alpha1/sd1;
  double zedd2 = alpha2/sd2;
  
  double pdf = exp(-log(2 * PI) - log(sd1) - log(sd2) - 0.5 * log(1-pow(tau,2)) -(0.5/temp5) * (pow(zedd1,2) + (-2 * tau * zedd1 + zedd2) * zedd2));
  
  
  if(pdf==0) {
    pdf = 1.1111e-300;
  };  
  
  double func = prod2+log(pdf);
  return (-func);
  
};


// [[Rcpp::export]]
double loop2(IntegerVector yS, IntegerVector yO, NumericVector linpredS, NumericVector linpredO, double rho, double tau, double sigma1, double sigma2, NumericVector w1, NumericVector a1, NumericVector group_aux, IntegerVector group, int M, NumericMatrix modes, NumericVector det_curv, List chol_curv) {
  
  int n = yS.size();
  
  NumericVector w2 = w1; 
  NumericVector a2 = a1;
  
  int la1 = a1.size();  
  int la2 = la1;
  
  
  NumericVector sum(n);
  
  NumericVector Li(M);
  NumericVector pdf(M);
  
  for(int j=0; j < M; ++j) {
    Li[j] = 0;
    pdf[j] = 0;
  };  
  
  
  double sd1 = sqrt(sigma1);
  double sd2 = sqrt(sigma2);
  double temp5 = 1 - pow(tau,2);
  
  
  for(int p=0; p < la2; ++p) {
    for(int m=0; m < la1; ++m) {
      
      NumericVector prod(M);
      
      for(int j=0; j < M; ++j) { 
        
        IntegerVector nj=c_which(group,(j+1));
        
        int first=nj[0]-1;
        int last=nj[(nj.size())-1]-1;
        
        NumericVector a=NumericVector::create(a1[m],a2[p]);
        
        NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
        double a1_st = a_st[0];
        double a2_st = a_st[1];
        
        double multi=1;
        
        for(int i=first; i < (last+1); ++i) {  
          if (yS[i]==0) {
            sum[i] = N(-(linpredS[i]+a1_st));
          }
          else if (yS[i]==1 && yO[i]==1) {
            sum[i] = bivnor(linpredS[i]+a1_st,linpredO[i]+a2_st,rho);
          }
          else if (yS[i]==1 && yO[i]==0) {
            sum[i] = bivnor(linpredS[i]+a1_st,-(linpredO[i]+a2_st),-rho);
          };
          multi *= sum[i];
        };
        
        prod[j] = multi;
        
        
        double zedd1 = (a1_st)/sd1;
        double zedd2 = (a2_st)/sd2;
        
        pdf[j] = exp(-log(2 * PI) - log(sd1) - log(sd2) - 0.5 * log(1-pow(tau,2)) -(0.5/temp5) * (pow(zedd1,2) + (-2 * tau * zedd1 + zedd2) * zedd2));
        
        
      };
      
      
      Li = Li + (w1[m]*w2[p]*prod*pdf*exp(pow(a1[m],2))*exp(pow(a2[p],2)));
      
    };
  }; 
  
  
  for(int j=0; j < M; ++j) {
    Li[j] = det_curv[j]*2*Li[j];
    if (Li[j]==0) {
      Li[j] = 1.1111e-300;
    };
  };  
  
  
  NumericVector Li_log = log(Li);
  
  double sum_Li = std::accumulate(Li_log.begin(), Li_log.end(), 0.000000000000000000000);
  
  double loglik = sum_Li;    
  return -loglik;
};


// [[Rcpp::export]]
NumericVector loop_grad(IntegerVector yS, IntegerVector yO, NumericMatrix XS, NumericMatrix XO, NumericVector linpredS, NumericVector linpredO, double rho, double tau, double sigma1, double sigma2, NumericVector w1, NumericVector a1, NumericVector group_aux, IntegerVector group, int M, NumericMatrix modes, NumericVector det_curv, List chol_curv) {
  
  int n = yS.size();
  
  NumericVector w2 = w1; 
  NumericVector a2 = a1;
  
  int la1 = a1.size();  
  int la2 = la1;
  
  // Likelihood 
  NumericVector sum1(n);
  
  NumericVector Li(M);
  NumericVector pdf(M);
  NumericVector pdf_dev1(M);
  NumericVector pdf_dev2(M);
  NumericVector pdf_dev3(M);
  
  for(int j=0; j < M; ++j) {
    Li[j] = 0;
    pdf[j] = 0;
  };  
  
  
  
  
  double sd1 = sqrt(sigma1);
  double sd2 = sqrt(sigma2);
  double temp5 = 1 - pow(tau,2);
  
  //std::cout << sd1 << '\n';
  
  for(int p=0; p < la2; ++p) {
    for(int m=0; m < la1; ++m) {
      
      NumericVector prod(M);
      
      for(int j=0; j < M; ++j) { 
        
        IntegerVector nj=c_which(group,(j+1));
        int first=nj[0]-1;
        int last=nj[(nj.size())-1]-1;
        
        NumericVector a=NumericVector::create(a1[m],a2[p]);
        
        NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
        double a1_st = a_st[0];
        double a2_st = a_st[1];
        
        double multi=1;
        
        for(int i=first; i < (last+1); ++i) {  
          if (yS[i]==0) {
            sum1[i] = N(-(linpredS[i]+a1_st));
          }
          else if (yS[i]==1 && yO[i]==1) {
            sum1[i] = bivnor(linpredS[i]+a1_st,linpredO[i]+a2_st,rho);
          }
          else if (yS[i]==1 && yO[i]==0) {
            sum1[i] = bivnor(linpredS[i]+a1_st,-(linpredO[i]+a2_st),-rho);
          };
          multi *= sum1[i];
        };
        
        prod[j] = multi;
        
        
        double zedd1 = (a1_st)/sd1;
        double zedd2 = (a2_st)/sd2;
        
        pdf[j] = exp(-log(2 * PI) - log(sd1) - log(sd2) - 0.5 * log(1-pow(tau,2)) -(0.5/temp5) * (pow(zedd1,2) + (-2 * tau * zedd1 + zedd2) * zedd2));
        
        
      };
      
      
      Li = Li + (w1[m]*w2[p]*prod*pdf*exp(pow(a1[m],2))*exp(pow(a2[p],2)));
      
    };
  }; 
  
  for(int j=0; j < M; ++j) {
    Li[j] = det_curv[j]*2*Li[j];
    if (Li[j]==0) {
      Li[j] = 1.1111e-10;
    };
  };
  
  //  for(int j=0; j < M; ++j) {
  //    std::cout << Li[j] << '\n';
  //  };
  
  // Gradients 
  int kS = XS.ncol(); int kO = XO.ncol();
  
  int par=kS+kO+4;
  
  NumericMatrix grad(par,M);
  
  NumericVector sum2(n);
  NumericVector sum3(n);
  
  double r = sqrt(1-rho*rho);
  
  NumericMatrix dprod(n,par);
  
  NumericMatrix group_sum1(M,kS);
  NumericMatrix group_sum2(M,kO);
  NumericVector group_sum3(M);
  
  
  for(int p=0; p < la2; ++p) {
    for(int m=0; m < la1; ++m) {
      
      NumericVector prod(M);
      
      for(int j=0; j < M; ++j) { 
        
        IntegerVector nj=c_which(group,(j+1));
        int first=nj[0]-1;
        int last=nj[(nj.size())-1]-1;
        
        NumericVector a=NumericVector::create(a1[m],a2[p]);
        
        NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
        double a1_st = a_st[0];
        double a2_st = a_st[1];
        
        double multi=1;
        
        for(int i=first; i < (last+1); ++i) {  
          if (yS[i]==0) {
            sum2[i] = N(-(linpredS[i]+a1_st));
          }
          else if (yS[i]==1 && yO[i]==1) {
            sum2[i] = bivnor(linpredS[i]+a1_st,linpredO[i]+a2_st,rho);
          }
          else if (yS[i]==1 && yO[i]==0) {
            sum2[i] = bivnor(linpredS[i]+a1_st,-(linpredO[i]+a2_st),-rho);
          };
          
          if (sum2[i]==0) {
            sum2[i] = 1.1111e-10;
          }
          
          multi *= sum2[i];
          //std::cout << multi << '\n';
        };
        prod[j] = multi;
        
      };
      

      for(int j=0; j < M; ++j) {
        if (prod[j]==0) {
          prod[j] = 1.1111e-10;
        };
      };
      
      // betaS:
      for(int k=0; k < kS; ++k){ // f?r die einzelnen Parameter..  
        
        for(int j=0; j < M; ++j) { 
          
          IntegerVector nj=c_which(group,(j+1));
          int first=nj[0]-1;
          int last=nj[(nj.size())-1]-1;
          
          NumericVector a=NumericVector::create(a1[m],a2[p]);
          
          NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
          double a1_st = a_st[0];
          double a2_st = a_st[1];
          
          double sum=0;
          
          for(int i=first; i < (last+1); ++i) {  
            if (yS[i]==0) {
              
              double dnm = dn(-(linpredS[i]+a1_st));
              if(dnm==0){
                dnm = 1.1111e-10;
              };
              
              
              dprod(i,k) = (XS(i,k) * (-dnm))/sum2[i];
            }
            else if (yS[i]==1 && yO[i]==1) {
              
              double dnm = dn(linpredS[i]+a1_st);
              if(dnm==0){
                dnm = 1.1111e-10;
              };
              
              double pnm = N(((linpredO[i]+a2_st)-rho*(linpredS[i]+a1_st))/r);
              if(pnm==0){
                pnm = 1.1111e-10;
              };
              
              dprod(i,k) = (XS(i,k) * dnm * pnm)/sum2[i];
            }
            else if (yS[i]==1 && yO[i]==0) {
              
              double dnm = dn(linpredS[i]+a1_st);
              if(dnm==0){
                dnm = 1.1111e-10;
              };
              
              double pnm = N((-(linpredO[i]+a2_st)+rho*(linpredS[i]+a1_st))/r);
              if(pnm==0){
                pnm = 1.1111e-10;
              };
              
              dprod(i,k) = (XS(i,k) * dnm * pnm)/sum2[i];
            };
            sum += dprod(i,k);
          };
          
          group_sum1(j,k) = sum;
          
          double zedd1 = (a1_st)/sd1;
          double zedd2 = (a2_st)/sd2;
          
          pdf[j] = exp(-log(2 * PI) - log(sd1) - log(sd2) - 0.5 * log(1-pow(tau,2)) -(0.5/temp5) * (pow(zedd1,2) + (-2 * tau * zedd1 + zedd2) * zedd2));
          
          grad(k,j) = grad(k,j) + ((det_curv[j]*2*w1[m]*w2[p]*exp(pow(a1[m],2))*exp(pow(a2[p],2)) * group_sum1(j,k)*prod[j]*pdf[j])/-Li[j]);
        };
        
      };
      
      
      // betaO:
      for(int k=0; k < kO; ++k){ 
        int c=kS+k;
        
        for(int j=0; j < M; ++j) { 
          
          IntegerVector nj=c_which(group,(j+1));
          int first=nj[0]-1;
          int last=nj[(nj.size())-1]-1;
          
          NumericVector a=NumericVector::create(a1[m],a2[p]);
          
          NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
          double a1_st = a_st[0];
          double a2_st = a_st[1];
          
          double sum=0;
          
          for(int i=first; i < (last+1); ++i) {  
            if (yS[i]==1 && yO[i]==1) {
              
              double dnm = dn(linpredO[i]+a2_st);
              if(dnm==0){
                dnm = 1.1111e-10;
              };
              
              double pnm = N(((linpredS[i]+a1_st)-rho*(linpredO[i]+a2_st))/r);
              if(pnm==0){
                pnm = 1.1111e-10;
              };
              
              dprod(i,c) = (XO(i,k) * dnm * pnm)/sum2[i];
            }
            else if (yS[i]==1 && yO[i]==0) {
              
              double dnm = dn(-(linpredO[i]+a2_st));
              if(dnm==0){
                dnm = 1.1111e-10;
              };
              
              double pnm = N(((linpredS[i]+a1_st)-rho*(linpredO[i]+a2_st))/r);
              if(pnm==0){
                pnm = 1.1111e-10;
              };
              
              dprod(i,c) = (XO(i,k) * (-dnm) * pnm)/sum2[i];
            };
            sum += dprod(i,c);
          };
          
          group_sum2(j,k) = sum;
          
          double zedd1 = (a1_st)/sd1;
          double zedd2 = (a2_st)/sd2;
          
          pdf[j] = exp(-log(2 * PI) - log(sd1) - log(sd2) - 0.5 * log(1-pow(tau,2)) -(0.5/temp5) * (pow(zedd1,2) + (-2 * tau * zedd1 + zedd2) * zedd2));
          
          grad(c,j) = grad(c,j) + ((det_curv[j]*2*w1[m]*w2[p]*exp(pow(a1[m],2))*exp(pow(a2[p],2)) * group_sum2(j,k)*prod[j]*pdf[j])/-Li[j]);
        };
      };
      
      
      // rho:
      
      for(int j=0; j < M; ++j) { 
        
        IntegerVector nj=c_which(group,(j+1));
        int first=nj[0]-1;
        int last=nj[(nj.size())-1]-1;
        
        NumericVector a=NumericVector::create(a1[m],a2[p]);
        
        NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
        double a1_st = a_st[0];
        double a2_st = a_st[1];
        
        double sum=0;
        
        for(int i=first; i < (last+1); ++i) {  
          if (yS[i]==1 && yO[i]==0) {
            
            double biv = biv_pdf(linpredS[i]+a1_st,-(linpredO[i]+a2_st), -rho);
            if(biv==0){
              biv = 1.1111e-10;
            };
            
            dprod(i,(kS+kO)) = (-(1-rho*rho) * biv)/sum2[i];
          }
          else if (yS[i]==1 && yO[i]==1) {
            
            double biv = biv_pdf(linpredS[i]+a1_st,linpredO[i]+a2_st, rho);
            if(biv==0){
              biv = 1.1111e-10;
            };
            
            dprod(i,(kS+kO)) = ((1-rho*rho) * biv)/sum2[i];
          };
          sum += dprod(i,(kS+kO));
          //std::cout << sum << '\n'; 
        };
        
        group_sum3[j] = sum;
        
        //std::cout << group_sum3[j] << '\n'; 
        
        double zedd1 = (a1_st)/sd1;
        double zedd2 = (a2_st)/sd2;
        
        pdf[j] = exp(-log(2 * PI) - log(sd1) - log(sd2) - 0.5 * log(1-pow(tau,2)) -(0.5/temp5) * (pow(zedd1,2) + (-2 * tau * zedd1 + zedd2) * zedd2));
        
        //std::cout << pdf[j] << '\n'; 
        
        grad((kS+kO),j) = grad((kS+kO),j) + ((det_curv[j]*2*w1[m]*w2[p]*exp(pow(a1[m],2))*exp(pow(a2[p],2)) * group_sum3[j]*prod[j]*pdf[j])/-Li[j]);
        
      };
      
      
      // sigma1:
      
      for(int j=0; j < M; ++j) { 
        
        NumericVector a=NumericVector::create(a1[m],a2[p]);
        
        NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
        double a1_st = a_st[0];
        double a2_st = a_st[1];
        
        double outer = exp(-log(2*PI)-log(sqrt(sigma1))-log(sqrt(sigma2)) - 0.5*log((1-pow(tau,2))) +((pow(a1_st,2)/sigma1 - (2*tau*a1_st*a2_st)/(sqrt(sigma1*sigma2))  + pow(a2_st,2)/sigma2) * (1/-(2*(1-pow(tau,2))))));
        double inner = -1/(2*sigma1) + (- 1/(2*(1-pow(tau,2))) * ( (a1_st*a2_st*sigma2*tau)/(pow(sigma1*sigma2,1.5)) - pow(a1_st,2)/pow(sigma1,2) ));
        
        pdf_dev1[j] = outer*inner;
        
        grad((kS+kO+1),j) = grad((kS+kO+1),j) + ((det_curv[j]*2*w1[m]*w2[p]*exp(pow(a1[m],2))*exp(pow(a2[p],2)) * prod[j]*pdf_dev1[j]*sigma1)/-Li[j]);
        
      };
      
      
      // sigma2:
      
      for(int j=0; j < M; ++j) { 
        
        NumericVector a=NumericVector::create(a1[m],a2[p]);
        
        NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
        double a1_st = a_st[0];
        double a2_st = a_st[1];
        
        double outer = exp(-log(2*PI)-log(sqrt(sigma1))-log(sqrt(sigma2)) - 0.5*log((1-pow(tau,2))) +((pow(a1_st,2)/sigma1 - (2*tau*a1_st*a2_st)/(sqrt(sigma1*sigma2))  + pow(a2_st,2)/sigma2) * (1/-(2*(1-pow(tau,2))))));
        double inner = -1/(2*sigma2) + (- 1/(2*(1-pow(tau,2))) * ( (a1_st*a2_st*sigma1*tau)/(pow(sigma1*sigma2,1.5)) - pow(a2_st,2)/pow(sigma2,2) ));
        
        pdf_dev2[j] = outer*inner;
        
        if (pdf_dev2[j]==0) {
          pdf_dev2[j]=prod[j]*pdf_dev2[j];
          pdf_dev2[j] = 1.1111e-300;
        };
        
        
        grad((kS+kO+2),j) = grad((kS+kO+2),j) + ((det_curv[j]*2*w1[m]*w2[p]*exp(pow(a1[m],2))*exp(pow(a2[p],2)) * prod[j]*pdf_dev2[j]*sigma2)/-Li[j]);
        
      };
      
      
      // tau:
      
      for(int j=0; j < M; ++j) { 
        
        NumericVector a=NumericVector::create(a1[m],a2[p]);
        
        NumericVector a_st=modes(j,_) + matmult_total(chol_curv[j], a, sqrt(2));
        double a1_st = a_st[0];
        double a2_st = a_st[1];
        
        double outer = exp(-log(2*PI)-log(sqrt(sigma1))-log(sqrt(sigma2)) - 0.5*log((1-pow(tau,2))) +((pow(a1_st,2)/sigma1 - (2*tau*a1_st*a2_st)/(sqrt(sigma1*sigma2))  + pow(a2_st,2)/sigma2) * (1/-(2*(1-pow(tau,2))))));
        double inner = -tau/(pow(tau,2)-1) + ((a1_st*a2_st)/((1-pow(tau,2))*sqrt(sigma1*sigma2)) - (tau*(pow(a1_st,2)/sigma1 - (2*tau*a1_st*a2_st)/(sqrt(sigma1*sigma2))  + pow(a2_st,2)/sigma2))/(pow(1-pow(tau,2),2)) );
        
        pdf_dev3[j] = outer*inner;
        
        grad((kS+kO+3),j) = grad((kS+kO+3),j) + ((det_curv[j]*2*w1[m]*w2[p]*exp(pow(a1[m],2))*exp(pow(a2[p],2)) * prod[j]*pdf_dev3[j]*(1-pow(tau,2)))/-Li[j]);
        
      };
      
      
      
    };
  }; 
  
  NumericVector dloglik = rowSums(grad);
  
  
  return dloglik;
};    

// [[Rcpp::export]]
double loop1(IntegerVector yS, IntegerVector yO, NumericVector linpredS, NumericVector linpredO, double rho, double tau, double sigma1, double sigma2, NumericVector w1, NumericVector a1, NumericVector group_aux, IntegerVector group, int M, NumericMatrix chol_vc_re) {
  
  int n = yS.size();
  
  NumericVector w2 = w1; 
  NumericVector a2 = a1;
  
  int la1 = a1.size();  
  int la2 = la1;
  
  NumericVector sum(n);
  
  NumericVector Li(M);
  //NumericVector pdf1(M);
  //NumericVector pdf2(M);
  //NumericVector pdf(M);
  
  for(int j=0; j < M; ++j) {
    Li[j] = 0;
    //pdf1[j] = 0;
    //pdf2[j] = 0;
    //pdf[j] = 0;
  };  
  
  
  for(int p=0; p < la2; ++p) {
    
    for(int m=0; m < la1; ++m) {
      
      NumericVector a=NumericVector::create(a1[m],a2[p]);
      
      //double a1_st=sqrt(sigma1)*sqrt(2)*a[0];
      //double a2_st=sqrt(sigma2)*sqrt(2)*(tau*a[0]+sqrt(1-pow(tau,2))*a[1]); 
      
      NumericVector a_st=matmult_total(chol_vc_re, a, sqrt(2));
      double a1_st = a_st[0];
      double a2_st = a_st[1];
      
      for(int i=0; i < n; ++i) {  
        if (yS[i]==0) {
          sum[i] = N(-(linpredS[i]+a1_st));
        }
        else if (yS[i]==1 && yO[i]==1) {
          sum[i] = bivnor(linpredS[i]+a1_st,linpredO[i]+a2_st,rho);
        }
        else if (yS[i]==1 && yO[i]==0) {
          sum[i] = bivnor(linpredS[i]+a1_st,-(linpredO[i]+a2_st),-rho);
        };
      };
      
      NumericVector prod = groupProd(sum,group_aux);
      Li += (1/PI*w1[m]*w2[p]*prod);
      
    };
    
  }; 
  
  for(int j=0; j < M; ++j) {
    if (Li[j]==0) {
      Li[j] = 1.1111e-300;
    };
  };  
  
  NumericVector Li_log = log(Li);
  
  double sum_Li = std::accumulate(Li_log.begin(), Li_log.end(), 0.000000000000000000000);
  
  double loglik = sum_Li;    
  return -loglik;
};



double pdf_stdN(double x){
  double pdf= 1/sqrt(2*PI) * exp(-pow(x,2)/2);
  return(pdf);
};


// [[Rcpp::export]]
NumericVector mode_grad(NumericVector par, int x, IntegerVector yS, IntegerVector yO, NumericVector linpredS, NumericVector linpredO, NumericVector group_aux, double rho, double tau, double sigma1, double sigma2) {
  
  double alpha1 = par[0];
  double alpha2 = par[1];
  
  int n = yS.size();
  
  NumericVector sum(n);
  NumericVector dsum1(n);
  NumericVector dsum2(n);
  
  
  if((round(tau*100)/100)==1){
    tau = 0.9999;
  };
  
  if((round(tau*100)/100)==-1){
    tau = -0.9999;
  };
  
  if((round(rho*100)/100)==1){
    rho = 0.9999;
  };
  
  if((round(rho*100)/100)==-1){
    rho = -0.9999;
  };
  
  if(sigma1 > 700){
    sigma1 = exp(300);
  };
  
  if(sigma2 > 700){
    sigma2 = exp(300);
  };
  
  if(sigma1 < -700){
    sigma1 = exp(-300);
  };
  
  if(sigma2 < -700){
    sigma2 = exp(-300);
  };
  
  
  if(sigma1 == 0){
    sigma1 =  1.1111e-300 ;
  };
  
  if(sigma2 == 0){
    sigma2 =  1.1111e-300 ;
  };
  
  for(int i=0; i < n; ++i) {  
    if (yS[i]==0) {
      sum[i] = N(-(linpredS[i]+alpha1));
    }
    else if (yS[i]==1 && yO[i]==1) {
      sum[i] = bivnor(linpredS[i]+alpha1,linpredO[i]+alpha2,rho);
    }
    else if (yS[i]==1 && yO[i]==0) {
      sum[i] = bivnor(linpredS[i]+alpha1,-(linpredO[i]+alpha2),-rho);
    };
    if (sum[i]==0) {
      sum[i] = 1.1111e-300;
    }
  };
  
  
  //NumericVector prod = groupSum(log(sum), group_aux);
  
  double r = sqrt(1-pow(rho,2));
    
    
    // alpha 1 
    
    // d loglik/d alpha1:
    for(int i=0; i < n; ++i) {  
      if (yS[i]==0) {
        dsum1[i] = pdf_stdN(-(linpredS[i]+alpha1)) * (-1);
      }
      else if (yS[i]==1 && yO[i]==1) {
        dsum1[i] = pdf_stdN((linpredS[i]+alpha1)) * N(((linpredO[i]+alpha2)-rho*(linpredS[i]+alpha1))/r);
      }
      else if (yS[i]==1 && yO[i]==0) {
        dsum1[i] =  pdf_stdN((linpredS[i]+alpha1)) * N((-(linpredO[i]+alpha2)+rho*(linpredS[i]+alpha1))/r);
      };
      if (dsum1[i]==0) {
        dsum1[i] = 1.1111e-300;
      }
    };
  
  
  // d pdf/d alpha1:
  double dpdf1 = (((2*alpha1)/sigma1) - ((2*tau*alpha2)/(sqrt(sigma1)*sqrt(sigma2)))) / (2*(1-pow(tau,2)));
  
  if(dpdf1==0) {
    dpdf1 = 1.1111e-300;
  };  
  
  // d ln g(t)/d alpha 1:
  double dalpha1 = groupSum((dsum1/sum), group_aux)[x] + dpdf1;
  
  // alpha 2 
  
  // d loglik/d alpha2:
  for(int i=0; i < n; ++i) {  
    if (yS[i]==1 && yO[i]==1) {
      dsum2[i] = pdf_stdN((linpredO[i]+alpha2)) * N(((linpredS[i]+alpha1)-rho*(linpredO[i]+alpha2))/r);
    }
    else if (yS[i]==1 && yO[i]==0) {
      dsum2[i] =  pdf_stdN(-(linpredO[i]+alpha2)) * N(((linpredS[i]+alpha1)+rho*(linpredO[i]+alpha2))/r) * (-1);
    };
    if (dsum2[i]==0) {
      dsum2[i] = 1.1111e-300;
    }
  };
  
  
  
  // d pdf/d alpha2:
  double dpdf2 = (((2*alpha2)/sigma2) - ((2*tau*alpha1)/(sqrt(sigma1)*sqrt(sigma2)))) / (2*(1-pow(tau,2)));
  
  if(dpdf2==0) {
    dpdf2 = 1.1111e-300;
  };  
  
  // d ln g(t)/d alpha 1:
  double dalpha2 = groupSum((dsum2/sum), group_aux)[x] + dpdf2;
  
  
  NumericVector func_grad(2);
  
  func_grad[0] = dalpha1;
  func_grad[1] = dalpha2;
  
  
  return (-func_grad);
  
};
