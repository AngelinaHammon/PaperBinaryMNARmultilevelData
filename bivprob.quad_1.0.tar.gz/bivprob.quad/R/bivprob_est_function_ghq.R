

loglik_bivprob_est_ghq <- function(data, yS, yO, XO, XS, kS, kO, group,sel, out, QP,...) {
  
  r_start <- suppressWarnings(glmer(sel,data=data,family=binomial(link=probit)))
  r_start@beta # -> Parameterwerte
  sigma1 <- r_start@theta^2 # -> Varianzwert -> noch log() bilden 
  if(round(sigma1,6)==0){sigma1 <- 0.0001}
  
  # Startwerte outcome equation: 
  y_start <- suppressWarnings(glmer(out,data=data[which(as.numeric(yS)==1),],family=binomial(link=probit)))
  y_start@beta # -> Parameterwerte
  sigma2 <- y_start@theta^2 # -> Varianzwert -> noch log() bilden
  if(round(sigma2,6)==0){sigma2 <- 0.0001}
  
  #sel_aux <- paste(deparse(formula(sel)))
  #sel_aux <- as.formula(unlist(strsplit(sel_aux," + (1",fixed=T))[1])
  
  #out_aux <- paste(deparse(formula(out)))
  #out_aux <- as.formula(unlist(strsplit(out_aux," + (1",fixed=T))[1])
  
  #rho_start <- selection(sel_aux, out_aux,data=data)
  
  start <- c(r_start@beta,y_start@beta, atanh(0.5) ,log(sigma1), log(sigma2) ,atanh(0.5))
  #start <- c(r_start@beta,y_start@beta, atanh(rho_start),log(r_start@theta^2), log(y_start@theta^2) , atanh(0.5))
  #print(start)
  opt <- optim(par=start, fn=loglik_bivprob_ghq, gr=NULL, method="BFGS", yS, yO, XO, XS, kS, kO, group,QP)
  #opt <- nlminb(start=start,
  #              objective = loglik_bivprob,
  #              gradient = loglik_bivprob_grad, hessian = NULL,
  #              yS=yS, yO=yO, XS=XS, XO=XO, kS=kS, kO=kO, group=group,
  #              control = list(trace=5, rel.tol=1e-4))
  
  hess <- numericHessian(loglik_bivprob_ghq,gr=NULL,t0=opt$par, yS=yS, yO=yO, XO=XO, XS=XS, kS=kS, kO=kO, group=group,QP=QP)
  #hess <- jacobian(func=loglik_bivprob_grad_alt, x=start,yS=yS, yO=yO, XO=XO, XS=XS, kS=kS, kO=kO, group=group)
  res <- list(estimates=opt$par,hessian=hess)
  
  return(res)
}

loglik_bivprob_est_ghq <- compiler::cmpfun(loglik_bivprob_est_ghq)
