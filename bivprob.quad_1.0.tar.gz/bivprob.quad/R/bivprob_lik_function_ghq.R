
loglik_bivprob_ghq <- function(param, yS, yO, XO, XS, kS, kO,group,QP,...) {
  
  #print(param)
  betaS    <- param[1:kS]
  betaO    <- param[(kS+1):(kS+kO)]
  rho      <- tanh(param[kS+kO+1])
  sigma1   <- exp(param[kS+kO+2])
  sigma2   <- exp(param[kS+kO+3])
  tau      <- tanh(param[kS+kO+4])
  
  group_aux <- c(0,cumsum(table(as.integer(factor(group)))))
  
  
  # calculate nodes and weights for given quadrature points:
  rule1 = gauss.quad(QP[1], "hermite")
  #rule2 = gauss.quad(QP[2], "hermite")
  rule = list(w_1=rule1$weights, a_1=rule1$nodes)#, w_2=rule2$weights, a_2=rule2$nodes)
  
  w1 <- rule$w_1
  a1 <- rule$a_1
  #w2 <- rule$w_2
  #a2 <- rule$a_2
  
  
  M <- length(table(group)) 
  N <- length(yS)
  
  # linear predictors:
  linpredS <- XS %*% betaS 
  linpredO <- XO %*% betaO
  
  
  #print(any(is.na(Li[,1])))
  
  if(round(tau,2)==1){
    tau <- 0.9999
  }
  
  if(round(tau,2)==-1){
    tau <- -0.9999
  }
  
  if(round(rho,2)==1){
    rho <- 0.9999
  }
  
  if(round(rho,2)==-1){
    rho <- -0.9999
  }
  
  
  if(param[kS+kO+2]>700){
    sigma1 <- exp(300)
  }
  
  if(param[kS+kO+3]>700){
    sigma2 <- exp(300)
  }
  
  if(param[kS+kO+2] < -700){
    sigma1 <- exp(-300)
  }
  
  if(param[kS+kO+3] < -700){
    sigma2 <- exp(-300)
  }
  
  vc_re <- matrix(0,2,2)
  vc_re[1,1] <- sigma1
  vc_re[2,2] <- sigma2
  vc_re[1,2] <- vc_re[2,1] <- sqrt(sigma1)*sqrt(sigma2)*tau
  
  chol_vc_re <- t(chol(vc_re))
  #det_sigma <- 2*pi*det(vc_re)
  #det_chol <- sqrt(2)*det(chol_vc_re)
  # modes, det_curv und sqrt_curv muss loop Funktion noch hinzugef?gt werden, aber wie Liste an c++ ?bergeben??
  # -> einfach mittels List!!! dann nur noch gucken wie man dann an die Matrizen kommt, denk mit Schleife 
  
  loglik <- loop1(yS, yO, linpredS, linpredO, rho, tau, sigma1, sigma2,  w1, a1, group_aux, group, M, chol_vc_re)
  
  #print(loglik)
  # Total Log-Likelihood:
  return(loglik)
  # wenn ich random effect drin habe, habe ich zwei nicht geschlossene Integrale, weshalb 
  # loglik nicht zu berechnen ist -> daf?r ben?tige ich quadrature (numerische Integration)
  
  
}

