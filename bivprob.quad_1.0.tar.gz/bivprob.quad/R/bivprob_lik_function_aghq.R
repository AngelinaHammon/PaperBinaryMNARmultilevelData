#library(VGAM) 
#library(PanelCount)
#library(statmod)
#library(Rcpp)
#library(RcppArmadillo)
#library(corpcor)
#library(Matrix)
#library(maxLik)

#sourceCpp("loop_likelihood_grad_AGHQ.cpp")

loglik_bivprob_aghq <- function(param, yS, yO, XO, XS, kS, kO,group,QP,...) {
  #cat("parameter values: ",param,"\n","\n")
  betaS    <- param[1:kS]
  betaO    <- param[(kS+1):(kS+kO)]
  rho      <- tanh(param[kS+kO+1])
  sigma1   <- exp(param[kS+kO+2])
  sigma2   <- exp(param[kS+kO+3])
  tau      <- tanh(param[kS+kO+4])
  
  group_aux <- c(0,cumsum(table(as.integer(factor(group)))))
  
  
  # calculate nodes and weights for given quadrature points:
  rule1 = gauss.quad(QP[1], "hermite")
  
  rule = list(w_1=rule1$weights, a_1=rule1$nodes)
  
  w1 <- rule$w_1
  a1 <- rule$a_1
  
  
  M <- length(table(group)) 
  N <- length(yS)
  
  # linear predictors:
  linpredS <- XS %*% betaS 
  linpredO <- XO %*% betaO
  
  # calculate mode and curvature:
  # mode:
  start2 <- c(0,0)
  modes <- t(sapply(1:length(table(group)), function(x) { # Funktion wird auf alle Cluster angewandt 
    optim(par=start2, fn=mode, gr=mode_grad, method="BFGS", x=x, yS=yS, yO=yO, linpredS=linpredS, linpredO=linpredO, group_aux=group_aux,rho=rho,tau=tau,
          sigma1=sigma1,sigma2=sigma2)$par
  })) 
  #print(modes)
  # hessian of mode:
  hess_mode <- lapply(1:nrow(modes), function(x) { 
    numericHessian(f=mode, grad=mode_grad, t0=modes[x,], x=x, yS=yS, yO=yO, linpredS=linpredS, linpredO=linpredO, group_aux=group_aux,rho=rho,tau=tau,
                   sigma1=sigma1,sigma2=sigma2)
  })
  
  #print(hess_mode)
  
  if(any(sapply(1:nrow(modes),function(x) is.na(hess_mode[[x]])) == T)) {
    hess_mode <- lapply(1:nrow(modes),function(x) diag(2))
  }
  
  if(any(sapply(1:nrow(modes),function(x) isSymmetric(hess_mode[[x]])) == F)) {
    hess_mode <- lapply(1:nrow(modes),function(x) as.matrix(forceSymmetric(hess_mode[[x]])))
  }
  
  
  hess_mode <- lapply(1:nrow(modes),function(x) make.positive.definite(hess_mode[[x]]))
    
  #print(hess_mode)

  det_curv <- sapply(1:nrow(modes),function(x) det(hess_mode[[x]])^(-1/2))
  #print(det_curv)
  #solve_hess_mode <- lapply(1:nrow(modes),function(x) make.positive.definite(solve(hess_mode[[x]],tol=1.2e-300)))
  #chol_curv <- lapply(1:nrow(modes),function(x) solve(t(chol(hess_mode[[x]])),tol=1.2e-300))
  solve_hess_mode <- lapply(1:nrow(modes),function(x) make.positive.definite(solve(hess_mode[[x]],tol=1.2e-300)))
  solve_hess_mode <- lapply(1:nrow(modes),function(x) as.matrix(nearPD(solve_hess_mode[[x]])$mat))
  chol_curv <- lapply(1:nrow(modes),function(x) t(chol(solve_hess_mode[[x]])))
  
  if(round(tau,2)==1){
    tau <- 0.9999
  }
  
  if(round(tau,2)==-1){
    tau <- -0.9999
  }
  
  if(round(rho,2)==1){
    rho <- 0.9999
  }
  
  if(round(rho,2)==-1){
    rho <- -0.9999
  }
  
  
  if(param[kS+kO+2]>700){
    sigma1 <- exp(300)
  }
  
  if(param[kS+kO+3]>700){
    sigma2 <- exp(300)
  }
  
  if(param[kS+kO+2] < -700){
    sigma1 <- exp(-300)
  }
  
  if(param[kS+kO+3] < -700){
    sigma2 <- exp(-300)
  }
  
  #grid <- createNIGrid(dim=2,type="GHe",level = H[1],ndConstruction="product")
  #w1 <- grid$weights
  #a1 <- grid$nodes
  
  group <- as.integer(factor(group))

  loglik <- loop2(yS, yO, linpredS, linpredO, rho, tau, sigma1, sigma2,  w1, a1, group_aux, group, M, modes, det_curv, chol_curv)
  
  #print(loglik)
  
  # Total Log-Likelihood:
  return(loglik)
  
}
